#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// ================= CẤU HÌNH HỆ THỐNG =================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Mã Token và Chat ID của bạn
String botToken ="8747685015:AAGuDDivoL2Lqu7K-OLAeUGoHrSOC7F52hE";
String chatID = "7392742747";

// Khai báo chân cắm linh kiện (Pinout)
#define LED_GREEN  19
#define LED_YELLOW 18
#define LED_RED    5
#define BUZZER     4
#define BUTTON     15

// Ngưỡng cảnh báo độ rung (m/s^2) - Mặc định gia tốc trọng trường là ~9.8 m/s^2
#define THRESHOLD_WARNING 15.0  // Mức 2: Rung lắc vừa (Đèn Vàng)
#define THRESHOLD_DANGER  25.0  // Mức 3: Rung lắc mạnh (Đèn Đỏ + Còi + Telegram)

Adafruit_MPU6050 mpu;

// Biến chống spam tin nhắn Telegram
unsigned long lastTelegramTime = 0;
const unsigned long TELEGRAM_COOLDOWN = 10000; // Khoảng cách giữa 2 tin nhắn là 10 giây

// ================= HÀM KHỞI TẠO =================
void setup() {
  Serial.begin(115200);

  // Cài đặt các chân I/O
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_YELLOW, OUTPUT);
  pinMode(LED_RED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(BUTTON, INPUT_PULLUP);

  // Khởi tạo cảm biến MPU6050
  if (!mpu.begin()) {
    Serial.println("Loi: Khong tim thay MPU6050!");
    while (1) { delay(10); }
  }
  Serial.println("MPU6050 da san sang.");
  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);

  // Kết nối WiFi mô phỏng Wokwi
  Serial.print("Dang ket noi WiFi...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi da ket noi!");
  
  // Test gửi tin nhắn lúc khởi động để kiểm tra Bot
  sendTelegramMessage("✅ Hệ thống báo động của Kha đã kết nối thành công!");
}

// ================= VÒNG LẶP CHÍNH =================
void loop() {
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  // Tính tổng gia tốc (độ rung) từ 3 trục X, Y, Z
  float totalAccel = sqrt(pow(a.acceleration.x, 2) + pow(a.acceleration.y, 2) + pow(a.acceleration.z, 2));
  
  // Đọc trạng thái nút nhấn (LOW là đang bấm do dùng INPUT_PULLUP)
  bool buttonPressed = (digitalRead(BUTTON) == LOW);

  // --- MỨC 3: NGUY HIỂM HOẶC BẤM NÚT KHẨN CẤP ---
  if (buttonPressed || totalAccel >= THRESHOLD_DANGER) {
    Serial.println("NGUY HIEM! Rung dong vuot nguong hoac nhan nut!");
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_YELLOW, LOW);
    digitalWrite(LED_RED, HIGH);
    tone(BUZZER, 1000); // Bật còi báo động

    // Gửi Telegram nếu đã qua thời gian chờ (Chống spam)
    if (millis() - lastTelegramTime > TELEGRAM_COOLDOWN) {
      if (buttonPressed) {
        sendTelegramMessage("🚨 BÁO ĐỘNG KHẨN CẤP: Nút nhấn an toàn đã bị kích hoạt!");
      } else {
        sendTelegramMessage("🚨 NGUY HIỂM: Phát hiện rung động cực mạnh! Vượt mốc 25 m/s2");
      }
      lastTelegramTime = millis();
    }
  }
  // --- MỨC 2: CẢNH BÁO ---
  else if (totalAccel >= THRESHOLD_WARNING) {
    Serial.println("CANH BAO! Rung dong tang cao!");
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_YELLOW, HIGH);
    digitalWrite(LED_RED, LOW);
    noTone(BUZZER); // Tắt còi
  }
  // --- MỨC 1: BÌNH THƯỜNG ---
  else {
    digitalWrite(LED_GREEN, HIGH);
    digitalWrite(LED_YELLOW, LOW);
    digitalWrite(LED_RED, LOW);
    noTone(BUZZER); // Tắt còi
  }

  delay(100); 
}

// ================= HÀM GỬI TELEGRAM =================
void sendTelegramMessage(String message) {
  if (WiFi.status() == WL_CONNECTED) {
    WiFiClientSecure client;
    client.setInsecure(); // Bỏ qua kiểm tra SSL (Bắt buộc cho Wokwi)
    client.setTimeout(15000); // Tăng thời gian chờ lên 15s chống lỗi -1
    
    HTTPClient http;
    // Tạo đường dẫn URL gửi tin nhắn
    String url = "https://api.telegram.org/bot" + botToken + "/sendMessage?chat_id=" + chatID + "&text=" + message;
    
    // Mã hóa khoảng trắng để URL không bị lỗi
    url.replace(" ", "%20"); 
    
    Serial.println("Dang gui du lieu den Telegram...");
    http.begin(client, url); 
    
    int httpResponseCode = http.GET();
    
    if (httpResponseCode > 0) {
      Serial.print("Da gui Telegram thanh cong! Ma phan hoi: ");
      Serial.println(httpResponseCode);
    } else {
      Serial.print("Loi mang Wokwi (Mat ket noi): ");
      Serial.println(httpResponseCode);
    }
    http.end();
  } else {
    Serial.println("Loi: Chua ket noi WiFi!");
  }
}